const https = require('https');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const keys = (process.env.GEMINI_API_KEYS || '').split(/[\n,]+/).map(k => k.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);
const key = keys[0];

const testModels = [
  'gemini-flash-latest',
  'gemini-flash-lite-latest',
  'gemini-3.7-flash',
  'gemini-3.5-flash',
  'gemini-3.1-flash-lite'
];

async function test(model) {
  const start = Date.now();
  return new Promise((resolve) => {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${key}`;
    const data = JSON.stringify({ contents: [{ parts: [{ text: "Salom" }] }] });
    const req = https.request(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': data.length }
    }, (res) => {
      let body = '';
      res.on('data', c => body += c);
      res.on('end', () => {
        const time = Date.now() - start;
        console.log(`[${model}] Status: ${res.statusCode} | Time: ${time}ms`);
        if (res.statusCode === 200) {
          try {
            const parsed = JSON.parse(body);
            const ans = parsed.candidates?.[0]?.content?.parts?.[0]?.text;
            console.log(`   Response: ${ans?.trim()}`);
          } catch(e) {}
        } else {
          console.log(`   Err: ${body.substring(0, 100)}`);
        }
        resolve();
      });
    });
    req.on('error', (e) => {
      console.log(`[${model}] Error: ${e.message}`);
      resolve();
    });
    req.write(data);
    req.end();
  });
}

(async () => {
  for (const m of testModels) {
    await test(m);
  }
})();
