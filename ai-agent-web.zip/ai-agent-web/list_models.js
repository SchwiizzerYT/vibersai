const https = require('https');
const path = require('path');
require('dotenv').config({ path: path.join(__dirname, '.env') });

const keys = (process.env.GEMINI_API_KEYS || '').split(/[\n,]+/).map(k => k.trim().replace(/^['"]|['"]$/g, '')).filter(Boolean);
const key = keys[0];

const url = 'https://generativelanguage.googleapis.com/v1beta/models';

https.get(url, { headers: { 'x-goog-api-key': key } }, (res) => {
  let body = '';
  res.on('data', c => body += c);
  res.on('end', () => {
    console.log("Status:", res.statusCode);
    try {
      const data = JSON.parse(body);
      const models = (data.models || []).map(m => m.name.replace('models/', ''));
      console.log("Available models:", models);
    } catch(e) {
      console.log("Body:", body);
    }
  });
});
